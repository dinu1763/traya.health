import React from 'react';

function ThankYouPage() {
  return (
    <div>
      <h1>Thank You!</h1>
      <p>Your feedback has been submitted successfully.</p>
    </div>
  );
}

export default ThankYouPage;
